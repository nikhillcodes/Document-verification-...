import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <span className="navbar-icon">🔗</span>
        <Link to="/" className="navbar-title">
          DocVerifier
        </Link>
        <span className="navbar-pill-badge">v1.0 • Web3</span>
      </div>

      <div className="navbar-right-section">
        <ul className="navbar-links">
          <li>
            <Link
              to="/"
              className={`nav-link ${pathname === "/" ? "nav-link--active" : ""}`}
            >
              Home
            </Link>
          </li>
          <li>
            <Link
              to="/register"
              className={`nav-link ${pathname === "/register" ? "nav-link--active" : ""}`}
            >
              Register
            </Link>
          </li>
          <li>
            <Link
              to="/verify"
              className={`nav-link ${pathname === "/verify" ? "nav-link--active" : ""}`}
            >
              Verify
            </Link>
          </li>
        </ul>

        {/* User Auth state */}
        <div className="navbar-auth-container">
          {user ? (
            <div className="nav-user-menu-wrapper">
              <button
                type="button"
                className="nav-user-chip"
                onClick={() => setDropdownOpen(!dropdownOpen)}
                aria-expanded={dropdownOpen}
              >
                <span className="user-chip-avatar">{user.roleIcon || "👤"}</span>
                <div className="user-chip-meta">
                  <span className="user-chip-name">{user.name}</span>
                  <span className="user-chip-role">{user.roleLabel || user.role}</span>
                </div>
                <span className="user-chip-arrow">▾</span>
              </button>

              {dropdownOpen && (
                <>
                  <div
                    className="dropdown-backdrop"
                    onClick={() => setDropdownOpen(false)}
                  />
                  <div className="nav-user-dropdown card">
                    <div className="dropdown-header">
                      <div className="dropdown-user-name">{user.name}</div>
                      <div className="dropdown-user-email">{user.email}</div>
                      {user.walletAddress && (
                        <div className="dropdown-wallet">
                          🦊 {user.walletAddress.slice(0, 6)}...{user.walletAddress.slice(-4)}
                        </div>
                      )}
                    </div>
                    <div className="dropdown-divider" />
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => {
                        setDropdownOpen(false);
                        navigate("/login");
                      }}
                    >
                      <span>👤</span> Account Details
                    </button>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => {
                        setDropdownOpen(false);
                        navigate(user.role === "verifier" ? "/verify" : "/register");
                      }}
                    >
                      <span>⚡</span> Dashboard Portal
                    </button>
                    <div className="dropdown-divider" />
                    <button
                      type="button"
                      className="dropdown-item dropdown-item-danger"
                      onClick={() => {
                        logout();
                        setDropdownOpen(false);
                      }}
                    >
                      <span>🚪</span> Sign Out
                    </button>
                  </div>
                </>
              )}
            </div>
          ) : (
            <Link
              to="/login"
              className={`btn btn-primary nav-login-btn ${
                pathname === "/login" ? "nav-login-btn--active" : ""
              }`}
            >
              <span>🔑</span> Sign In
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
