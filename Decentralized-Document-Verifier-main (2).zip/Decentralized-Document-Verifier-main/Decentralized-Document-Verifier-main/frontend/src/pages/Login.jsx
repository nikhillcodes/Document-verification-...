import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth, DEMO_ACCOUNTS } from "../context/AuthContext";

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, login, register, connectWallet, loginAsDemo, logout, walletConnecting } = useAuth();

  // Mode: "signin" | "signup" | "wallet"
  const [activeTab, setActiveTab] = useState("signin");

  // Sign In form fields
  const [signInEmail, setSignInEmail] = useState("");
  const [signInPassword, setSignInPassword] = useState("");
  const [signInRole, setSignInRole] = useState("issuer");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Sign Up form fields
  const [signUpName, setSignUpName] = useState("");
  const [signUpEmail, setSignUpEmail] = useState("");
  const [signUpPassword, setSignUpPassword] = useState("");
  const [signUpConfirmPassword, setSignUpConfirmPassword] = useState("");
  const [signUpRole, setSignUpRole] = useState("issuer");
  const [signUpOrg, setSignUpOrg] = useState("");

  // States
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotSent, setForgotSent] = useState(false);

  // Password strength helper
  const getPasswordStrength = (pass) => {
    if (!pass) return { score: 0, text: "", color: "" };
    let score = 0;
    if (pass.length >= 6) score++;
    if (pass.length >= 10) score++;
    if (/[A-Z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;

    if (score <= 2) return { score: 1, text: "Weak", color: "#ef4444" };
    if (score <= 4) return { score: 2, text: "Good", color: "#f59e0b" };
    return { score: 3, text: "Strong", color: "#22c55e" };
  };

  const strength = getPasswordStrength(signUpPassword);

  const clearAlerts = () => {
    setError("");
    setSuccessMsg("");
  };

  // Handle Sign In submission
  const handleSignInSubmit = async (e) => {
    e.preventDefault();
    clearAlerts();

    if (!signInEmail.trim()) {
      setError("Please enter your email address.");
      return;
    }
    if (!signInPassword) {
      setError("Please enter your password.");
      return;
    }

    setLoading(true);
    try {
      const loggedUser = await login(signInEmail, signInPassword, signInRole);
      setSuccessMsg(`Welcome back, ${loggedUser.name}!`);
      setTimeout(() => {
        const dest = loggedUser.role === "issuer" ? "/register" : "/verify";
        navigate(location.state?.from || dest);
      }, 700);
    } catch (err) {
      setError(err.message || "Failed to sign in.");
    } finally {
      setLoading(false);
    }
  };

  // Handle Sign Up submission
  const handleSignUpSubmit = async (e) => {
    e.preventDefault();
    clearAlerts();

    if (!signUpName.trim()) {
      setError("Please enter your full name or organization name.");
      return;
    }
    if (!signUpEmail.trim()) {
      setError("Please enter a valid email address.");
      return;
    }
    if (signUpPassword.length < 6) {
      setError("Password must be at least 6 characters long.");
      return;
    }
    if (signUpPassword !== signUpConfirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);
    try {
      const newUser = await register(
        signUpName,
        signUpEmail,
        signUpPassword,
        signUpRole,
        signUpOrg
      );
      setSuccessMsg(`Account created successfully! Welcome, ${newUser.name}.`);
      setTimeout(() => {
        const dest = newUser.role === "issuer" ? "/register" : "/verify";
        navigate(dest);
      }, 800);
    } catch (err) {
      setError(err.message || "Account creation failed.");
    } finally {
      setLoading(false);
    }
  };

  // Handle Web3 Wallet Connect
  const handleWalletConnect = async () => {
    clearAlerts();
    try {
      const walletUser = await connectWallet();
      setSuccessMsg(`Wallet connected: ${walletUser.walletAddress.slice(0, 8)}...`);
      setTimeout(() => {
        navigate("/register");
      }, 750);
    } catch (err) {
      setError(err.message || "Failed to connect Web3 wallet.");
    }
  };

  // Handle 1-click Demo Login
  const handleQuickDemo = async (role) => {
    clearAlerts();
    setLoading(true);
    try {
      const demoUser = await loginAsDemo(role);
      setSuccessMsg(`Logged in as ${demoUser.roleLabel} (${demoUser.name})`);
      setTimeout(() => {
        const dest = role === "issuer" ? "/register" : "/verify";
        navigate(dest);
      }, 600);
    } catch (err) {
      setError("Failed to initialize demo login.");
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPasswordSubmit = (e) => {
    e.preventDefault();
    if (!forgotEmail.trim()) return;
    setForgotSent(true);
  };

  // If already authenticated, show user overview card
  if (user) {
    return (
      <div className="page page-login">
        <div className="login-card-container">
          <div className="card login-card auth-profile-card">
            <div className="auth-profile-badge">{user.roleIcon} Active Session</div>
            <h1 className="login-title">You're Currently Signed In</h1>
            <p className="login-subtitle">
              Connected as <span className="highlight-text">{user.name}</span>
            </p>

            <div className="user-details-box">
              <div className="user-avatar-large">
                <span>{user.roleIcon || "👤"}</span>
              </div>
              <div className="user-info-rows">
                <div className="user-info-item">
                  <span className="info-key">Name:</span>
                  <span className="info-val">{user.name}</span>
                </div>
                <div className="user-info-item">
                  <span className="info-key">Email / ID:</span>
                  <span className="info-val">{user.email}</span>
                </div>
                <div className="user-info-item">
                  <span className="info-key">Role:</span>
                  <span className="info-val role-tag">
                    {user.roleLabel || user.role}
                  </span>
                </div>
                <div className="user-info-item">
                  <span className="info-key">Organization:</span>
                  <span className="info-val">{user.organization || "Public Network"}</span>
                </div>
                {user.walletAddress && (
                  <div className="user-info-item">
                    <span className="info-key">Wallet Address:</span>
                    <span className="info-val mono-val">
                      {user.walletAddress.slice(0, 10)}...{user.walletAddress.slice(-8)}
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="auth-actions-row">
              <button
                className="btn btn-primary"
                onClick={() => navigate(user.role === "verifier" ? "/verify" : "/register")}
              >
                {user.role === "verifier" ? "Go to Verification Portal" : "Go to Register Document"}
              </button>
              <button
                className="btn btn-secondary"
                onClick={() => navigate("/verify")}
              >
                Verify Lookup
              </button>
              <button
                className="btn btn-outline btn-logout-action"
                onClick={logout}
              >
                Sign Out
              </button>
            </div>

            <div className="quick-switch-section">
              <span className="quick-switch-label">Switch to another Demo Persona:</span>
              <div className="demo-pills">
                <button
                  type="button"
                  className="demo-pill"
                  onClick={() => handleQuickDemo("issuer")}
                >
                  🏛️ Issuer
                </button>
                <button
                  type="button"
                  className="demo-pill"
                  onClick={() => handleQuickDemo("verifier")}
                >
                  🔍 Verifier
                </button>
                <button
                  type="button"
                  className="demo-pill"
                  onClick={() => handleQuickDemo("admin")}
                >
                  🛡️ Admin
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page page-login">
      {/* Background glowing decorations */}
      <div className="login-mesh-bg" aria-hidden="true">
        <div className="mesh-circle mesh-1" />
        <div className="mesh-circle mesh-2" />
      </div>

      <div className="login-card-container">
        {/* Quick Demo Fast-Track Bar */}
        <div className="demo-fast-track card">
          <div className="demo-fast-track-header">
            <span className="demo-badge">🚀 Instant 1-Click Demo Login</span>
            <span className="demo-hint">Pick a role to test immediately without typing:</span>
          </div>
          <div className="demo-buttons-grid">
            <button
              type="button"
              className="demo-btn demo-btn-issuer"
              onClick={() => handleQuickDemo("issuer")}
              disabled={loading}
            >
              <span className="demo-btn-icon">🏛️</span>
              <span className="demo-btn-content">
                <strong>Issuer Demo</strong>
                <small>Upload to IPFS & Notarize</small>
              </span>
            </button>

            <button
              type="button"
              className="demo-btn demo-btn-verifier"
              onClick={() => handleQuickDemo("verifier")}
              disabled={loading}
            >
              <span className="demo-btn-icon">🔍</span>
              <span className="demo-btn-content">
                <strong>Verifier Demo</strong>
                <small>Inspect & Validate CIDs</small>
              </span>
            </button>

            <button
              type="button"
              className="demo-btn demo-btn-admin"
              onClick={() => handleQuickDemo("admin")}
              disabled={loading}
            >
              <span className="demo-btn-icon">🛡️</span>
              <span className="demo-btn-content">
                <strong>Admin Demo</strong>
                <small>Revoke & Manage Authority</small>
              </span>
            </button>
          </div>
        </div>

        {/* Main Auth Card */}
        <div className="card login-card">
          <div className="login-header">
            <div className="login-logo-icon">🔗</div>
            <h1 className="login-title">DocVerifier Authentication</h1>
            <p className="login-subtitle">
              Secure blockchain identity gateway for decentralized document management
            </p>
          </div>

          {/* Navigation Tabs */}
          <div className="auth-tab-switchers" role="tablist">
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "signin"}
              className={`auth-tab-btn ${activeTab === "signin" ? "auth-tab-btn--active" : ""}`}
              onClick={() => {
                setActiveTab("signin");
                clearAlerts();
              }}
            >
              🔑 Sign In
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "signup"}
              className={`auth-tab-btn ${activeTab === "signup" ? "auth-tab-btn--active" : ""}`}
              onClick={() => {
                setActiveTab("signup");
                clearAlerts();
              }}
            >
              ✨ Create Account
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === "wallet"}
              className={`auth-tab-btn ${activeTab === "wallet" ? "auth-tab-btn--active" : ""}`}
              onClick={() => {
                setActiveTab("wallet");
                clearAlerts();
              }}
            >
              🦊 Web3 Wallet
            </button>
          </div>

          {/* Alerts */}
          {error && (
            <div className="alert alert--error" role="alert">
              <span aria-hidden="true">⚠️</span> {error}
              <button
                type="button"
                className="alert-close"
                onClick={() => setError("")}
                aria-label="Dismiss error"
              >
                ✕
              </button>
            </div>
          )}

          {successMsg && (
            <div className="alert alert--success" role="alert">
              <span aria-hidden="true">✅</span> {successMsg}
            </div>
          )}

          {/* TAB 1: SIGN IN */}
          {activeTab === "signin" && (
            <form onSubmit={handleSignInSubmit} className="auth-form">
              <div className="form-group">
                <label className="form-label" htmlFor="signin-email">
                  Email Address
                </label>
                <div className="input-with-icon">
                  <span className="input-icon">✉️</span>
                  <input
                    id="signin-email"
                    type="email"
                    className="form-input form-input-iconified"
                    placeholder="e.g. issuer@university.edu"
                    value={signInEmail}
                    onChange={(e) => setSignInEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <div className="label-with-action">
                  <label className="form-label" htmlFor="signin-password">
                    Password
                  </label>
                  <button
                    type="button"
                    className="link-btn-text"
                    onClick={() => setShowForgotModal(true)}
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="input-with-icon">
                  <span className="input-icon">🔒</span>
                  <input
                    id="signin-password"
                    type={showPassword ? "text" : "password"}
                    className="form-input form-input-iconified"
                    placeholder="Enter your secret password"
                    value={signInPassword}
                    onChange={(e) => setSignInPassword(e.target.value)}
                    required
                  />
                  <button
                    type="button"
                    className="password-toggle-btn"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? "🙈" : "👁️"}
                  </button>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Signing in as Role</label>
                <div className="role-selector-grid">
                  <label className={`role-option-card ${signInRole === "issuer" ? "role-option--selected" : ""}`}>
                    <input
                      type="radio"
                      name="signin-role"
                      value="issuer"
                      checked={signInRole === "issuer"}
                      onChange={() => setSignInRole("issuer")}
                      className="sr-only"
                    />
                    <div className="role-icon">🏛️</div>
                    <div className="role-name">Issuer</div>
                    <div className="role-desc">Upload & Notarize</div>
                  </label>

                  <label className={`role-option-card ${signInRole === "verifier" ? "role-option--selected" : ""}`}>
                    <input
                      type="radio"
                      name="signin-role"
                      value="verifier"
                      checked={signInRole === "verifier"}
                      onChange={() => setSignInRole("verifier")}
                      className="sr-only"
                    />
                    <div className="role-icon">🔍</div>
                    <div className="role-name">Verifier</div>
                    <div className="role-desc">Verify CIDs</div>
                  </label>

                  <label className={`role-option-card ${signInRole === "admin" ? "role-option--selected" : ""}`}>
                    <input
                      type="radio"
                      name="signin-role"
                      value="admin"
                      checked={signInRole === "admin"}
                      onChange={() => setSignInRole("admin")}
                      className="sr-only"
                    />
                    <div className="role-icon">🛡️</div>
                    <div className="role-name">Admin</div>
                    <div className="role-desc">Full Control</div>
                  </label>
                </div>
              </div>

              <div className="form-row-checkbox">
                <label className="checkbox-container">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                  />
                  <span className="checkbox-label">Keep me signed in for 30 days</span>
                </label>
              </div>

              <button
                type="submit"
                className="btn btn-primary btn-block btn-lg"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="spinner" /> Authenticating...
                  </>
                ) : (
                  "Sign In to DocVerifier →"
                )}
              </button>
            </form>
          )}

          {/* TAB 2: CREATE ACCOUNT */}
          {activeTab === "signup" && (
            <form onSubmit={handleSignUpSubmit} className="auth-form">
              <div className="form-group">
                <label className="form-label" htmlFor="signup-name">
                  Full Name / Organization Name
                </label>
                <div className="input-with-icon">
                  <span className="input-icon">👤</span>
                  <input
                    id="signup-name"
                    type="text"
                    className="form-input form-input-iconified"
                    placeholder="e.g. Stanford Registrar or Dr. Alan Turing"
                    value={signUpName}
                    onChange={(e) => setSignUpName(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="signup-email">
                  Work / Official Email
                </label>
                <div className="input-with-icon">
                  <span className="input-icon">✉️</span>
                  <input
                    id="signup-email"
                    type="email"
                    className="form-input form-input-iconified"
                    placeholder="e.g. registrar@institution.org"
                    value={signUpEmail}
                    onChange={(e) => setSignUpEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="signup-org">
                  Affiliated Organization (Optional)
                </label>
                <div className="input-with-icon">
                  <span className="input-icon">🏢</span>
                  <input
                    id="signup-org"
                    type="text"
                    className="form-input form-input-iconified"
                    placeholder="e.g. Acme Verification Authority"
                    value={signUpOrg}
                    onChange={(e) => setSignUpOrg(e.target.value)}
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Select Your System Role</label>
                <div className="role-selector-grid">
                  <label className={`role-option-card ${signUpRole === "issuer" ? "role-option--selected" : ""}`}>
                    <input
                      type="radio"
                      name="signup-role"
                      value="issuer"
                      checked={signUpRole === "issuer"}
                      onChange={() => setSignUpRole("issuer")}
                      className="sr-only"
                    />
                    <div className="role-icon">🏛️</div>
                    <div className="role-name">Issuer</div>
                    <div className="role-desc">Upload & Notarize</div>
                  </label>

                  <label className={`role-option-card ${signUpRole === "verifier" ? "role-option--selected" : ""}`}>
                    <input
                      type="radio"
                      name="signup-role"
                      value="verifier"
                      checked={signUpRole === "verifier"}
                      onChange={() => setSignUpRole("verifier")}
                      className="sr-only"
                    />
                    <div className="role-icon">🔍</div>
                    <div className="role-name">Verifier</div>
                    <div className="role-desc">Validate CIDs</div>
                  </label>

                  <label className={`role-option-card ${signUpRole === "admin" ? "role-option--selected" : ""}`}>
                    <input
                      type="radio"
                      name="signup-role"
                      value="admin"
                      checked={signUpRole === "admin"}
                      onChange={() => setSignUpRole("admin")}
                      className="sr-only"
                    />
                    <div className="role-icon">🛡️</div>
                    <div className="role-name">Admin</div>
                    <div className="role-desc">Management</div>
                  </label>
                </div>
              </div>

              <div className="form-row-duo">
                <div className="form-group">
                  <label className="form-label" htmlFor="signup-password">
                    Password
                  </label>
                  <div className="input-with-icon">
                    <span className="input-icon">🔒</span>
                    <input
                      id="signup-password"
                      type={showPassword ? "text" : "password"}
                      className="form-input form-input-iconified"
                      placeholder="Min 6 chars"
                      value={signUpPassword}
                      onChange={(e) => setSignUpPassword(e.target.value)}
                      required
                    />
                  </div>
                  {signUpPassword && (
                    <div className="password-strength-indicator">
                      <div className="strength-bar-track">
                        <div
                          className="strength-bar-fill"
                          style={{
                            width: `${(strength.score / 3) * 100}%`,
                            backgroundColor: strength.color,
                          }}
                        />
                      </div>
                      <span className="strength-label" style={{ color: strength.color }}>
                        {strength.text} strength
                      </span>
                    </div>
                  )}
                </div>

                <div className="form-group">
                  <label className="form-label" htmlFor="signup-confirm-password">
                    Confirm Password
                  </label>
                  <div className="input-with-icon">
                    <span className="input-icon">🔒</span>
                    <input
                      id="signup-confirm-password"
                      type={showPassword ? "text" : "password"}
                      className="form-input form-input-iconified"
                      placeholder="Repeat password"
                      value={signUpConfirmPassword}
                      onChange={(e) => setSignUpConfirmPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="btn btn-primary btn-block btn-lg"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="spinner" /> Creating Account...
                  </>
                ) : (
                  "Create Account & Get Started →"
                )}
              </button>
            </form>
          )}

          {/* TAB 3: WEB3 WALLET */}
          {activeTab === "wallet" && (
            <div className="wallet-auth-container">
              <div className="wallet-hero-banner">
                <div className="wallet-hex-icon">🦊</div>
                <h3>Connect Web3 Wallet</h3>
                <p>
                  Sign in cryptographically using your Ethereum address. No passwords or centralized database required.
                </p>
              </div>

              <div className="wallet-providers-list">
                <button
                  type="button"
                  className="wallet-provider-btn"
                  onClick={handleWalletConnect}
                  disabled={walletConnecting}
                >
                  <span className="wallet-logo">🦊</span>
                  <div className="wallet-info">
                    <strong>MetaMask / Injected Provider</strong>
                    <small>Connect browser extension or mobile wallet</small>
                  </div>
                  <span className="wallet-arrow">→</span>
                </button>

                <button
                  type="button"
                  className="wallet-provider-btn"
                  onClick={handleWalletConnect}
                  disabled={walletConnecting}
                >
                  <span className="wallet-logo">⚡</span>
                  <div className="wallet-info">
                    <strong>Hardhat / Local Test Signer</strong>
                    <small>Pre-configured local development account</small>
                  </div>
                  <span className="wallet-arrow">→</span>
                </button>
              </div>

              <div className="wallet-security-note">
                <span>🔐</span>
                <p>
                  Connecting your wallet only allows the app to view your public address. Your private keys never leave your device.
                </p>
              </div>
            </div>
          )}

          {/* Footer inside card */}
          <div className="login-card-footer">
            <p className="privacy-disclaimer">
              🛡️ Decentralized &amp; End-to-End Cryptographically Verified on Ethereum &amp; IPFS
            </p>
          </div>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="modal-overlay" onClick={() => setShowForgotModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Reset Your Password</h3>
              <button
                type="button"
                className="modal-close-btn"
                onClick={() => setShowForgotModal(false)}
              >
                ✕
              </button>
            </div>
            {forgotSent ? (
              <div className="modal-body modal-success-body">
                <div className="modal-success-icon">📬</div>
                <h4>Password Reset Link Sent!</h4>
                <p>
                  If an account exists for <strong>{forgotEmail}</strong>, we've sent password reset instructions to your inbox.
                </p>
                <button
                  type="button"
                  className="btn btn-primary btn-block"
                  onClick={() => {
                    setShowForgotModal(false);
                    setForgotSent(false);
                    setForgotEmail("");
                  }}
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleForgotPasswordSubmit} className="modal-body">
                <p className="modal-description">
                  Enter the email associated with your account, and we'll send you a secure verification link to reset your credentials.
                </p>
                <div className="form-group">
                  <label className="form-label" htmlFor="forgot-email">
                    Account Email
                  </label>
                  <input
                    id="forgot-email"
                    type="email"
                    className="form-input"
                    placeholder="e.g. issuer@university.edu"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="modal-actions">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => setShowForgotModal(false)}
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Send Reset Link
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
