import React, { useState } from "react";
import { Link } from "react-router-dom";
import UploadForm from "../components/UploadForm";
import VerificationResult from "../components/VerificationResult";
import { registerDocument } from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const { user } = useAuth();
  const [loading, setLoading]   = useState(false);
  const [result,  setResult]    = useState(null);   // success response
  const [error,   setError]     = useState("");      // error message

  async function handleSubmit(documentId, file) {
    setLoading(true);
    setError("");
    setResult(null);

    try {
      const data = await registerDocument(documentId, file);
      setResult(data);
    } catch (err) {
      setError(err.message || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handleReset() {
    setResult(null);
    setError("");
  }

  return (
    <div className="page page-register">
      <div className="page-header">
        <h1 className="page-title">Register Document</h1>
        <p className="page-description">
          Upload a document to IPFS and store its CID permanently on the
          blockchain. You will receive a unique CID to use for verification later.
        </p>
      </div>

      {/* User Session Banner */}
      {user ? (
        <div className="info-box" style={{ marginBottom: "var(--space-lg)", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "0.5rem" }}>
          <div>
            <span>{user.roleIcon || "👤"}</span> <strong>{user.name}</strong> &bull; <span style={{ color: "var(--color-primary)" }}>{user.roleLabel || user.role}</span> &bull; <small style={{ color: "var(--color-text-muted)" }}>{user.organization || "Independent"}</small>
          </div>
          <Link to="/login" style={{ fontSize: "0.85rem", fontWeight: 600 }}>
            Switch Account &rarr;
          </Link>
        </div>
      ) : (
        <div className="info-box" style={{ marginBottom: "var(--space-lg)", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "0.5rem" }}>
          <div>
            <span>💡</span> <strong>Not signed in:</strong> You can register documents anonymously, or <Link to="/login">sign in / use 1-click demo</Link> for role management.
          </div>
          <Link to="/login" className="btn btn-secondary" style={{ padding: "0.3rem 0.8rem", fontSize: "0.82rem" }}>
            Sign In &rarr;
          </Link>
        </div>
      )}

      {/* Error banner */}
      {error && (
        <div className="alert alert--error" role="alert">
          <span aria-hidden="true">⚠️</span> {error}
          <button
            className="alert-close"
            onClick={() => setError("")}
            aria-label="Dismiss error"
          >
            ✕
          </button>
        </div>
      )}

      {/* Show form or success result */}
      {result ? (
        <VerificationResult type="register" data={result} onReset={handleReset} />
      ) : (
        <UploadForm onSubmit={handleSubmit} loading={loading} />
      )}

      {/* Info box */}
      {!result && (
        <div className="info-box">
          <h3>📋 What happens when you register?</h3>
          <ol>
            <li>Your file is uploaded to IPFS via Pinata.</li>
            <li>IPFS generates a CID — a unique fingerprint of your file.</li>
            <li>
              The Document ID and CID are stored on the Ethereum blockchain via
              a smart contract.
            </li>
            <li>Save your CID — you will need it to verify this document.</li>
          </ol>
        </div>
      )}
    </div>
  );
}
