import React from "react";
import { Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Register from "./pages/Register";
import Verify from "./pages/Verify";
import Login from "./pages/Login";

export default function App() {
  return (
    <AuthProvider>
      <div className="app">
        <Navbar />

        <main className="main-content">
          <Routes>
            <Route path="/"         element={<Home />} />
            <Route path="/login"    element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/verify"   element={<Verify />} />
          </Routes>
        </main>

        <footer className="footer">
          <div className="footer-content">
            <p>
              Decentralized Document Verifier &mdash; Powered by <strong>IPFS</strong> &amp; <strong>Ethereum Blockchain</strong>
            </p>
            <p className="footer-subtext">
              Cryptographically verified, tamper-proof, and trustless infrastructure.
            </p>
          </div>
        </footer>
      </div>
    </AuthProvider>
  );
}
