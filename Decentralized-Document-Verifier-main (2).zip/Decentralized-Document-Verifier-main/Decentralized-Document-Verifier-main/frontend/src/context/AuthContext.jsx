import React, { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext(null);

const STORAGE_KEY = "docverifier_auth_user";

// Pre-defined demo accounts for 1-click testing
export const DEMO_ACCOUNTS = {
  issuer: {
    id: "user_issuer_01",
    name: "Dr. Evelyn Reed",
    email: "evelyn.reed@university.edu",
    role: "issuer",
    roleLabel: "Authorized Issuer",
    roleIcon: "🏛️",
    organization: "Global Academic Verification Board",
    walletAddress: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
    authType: "credentials",
  },
  verifier: {
    id: "user_verifier_02",
    name: "Marcus Vance",
    email: "marcus.vance@verifylab.io",
    role: "verifier",
    roleLabel: "Compliance Verifier",
    roleIcon: "🔍",
    organization: "TrustLayer Audit Services",
    walletAddress: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC",
    authType: "credentials",
  },
  admin: {
    id: "user_admin_03",
    name: "Sarah Chen",
    email: "sarah.chen@docverifier.network",
    role: "admin",
    roleLabel: "Protocol Admin",
    roleIcon: "🛡️",
    organization: "DocVerifier Core DAO",
    walletAddress: "0x90F79bf6EB2c4f870365E785982E1f101E93b906",
    authType: "credentials",
  },
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [walletConnecting, setWalletConnecting] = useState(false);

  useEffect(() => {
    if (user) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, [user]);

  // Standard email/password login
  const login = async (email, password, role = "issuer") => {
    // Simulate network delay for realistic experience
    await new Promise((resolve) => setTimeout(resolve, 600));

    // Determine role label and icon
    let roleLabel = "Authorized Issuer";
    let roleIcon = "🏛️";
    if (role === "verifier") {
      roleLabel = "Compliance Verifier";
      roleIcon = "🔍";
    } else if (role === "admin") {
      roleLabel = "Protocol Admin";
      roleIcon = "🛡️";
    } else if (role === "viewer") {
      roleLabel = "Public Viewer";
      roleIcon = "👤";
    }

    const newUser = {
      id: `usr_${Date.now()}`,
      name: email.split("@")[0].replace(/[^a-zA-Z0-9]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) || "Verifier User",
      email: email.trim(),
      role,
      roleLabel,
      roleIcon,
      organization: role === "issuer" ? "Certified Document Issuer Corp" : "Autonomous Verifier Node",
      walletAddress: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
      authType: "email",
      loggedInAt: new Date().toISOString(),
    };

    setUser(newUser);
    return newUser;
  };

  // User registration
  const register = async (name, email, password, role = "issuer", organization = "") => {
    await new Promise((resolve) => setTimeout(resolve, 700));

    let roleLabel = "Authorized Issuer";
    let roleIcon = "🏛️";
    if (role === "verifier") {
      roleLabel = "Compliance Verifier";
      roleIcon = "🔍";
    } else if (role === "admin") {
      roleLabel = "Protocol Admin";
      roleIcon = "🛡️";
    }

    const newUser = {
      id: `usr_${Date.now()}`,
      name: name.trim() || "New Member",
      email: email.trim(),
      role,
      roleLabel,
      roleIcon,
      organization: organization.trim() || (role === "issuer" ? "Independent Issuer" : "Independent Auditor"),
      walletAddress: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
      authType: "email",
      registeredAt: new Date().toISOString(),
    };

    setUser(newUser);
    return newUser;
  };

  // Web3 Wallet connection (MetaMask or simulated provider)
  const connectWallet = async () => {
    setWalletConnecting(true);
    try {
      if (typeof window !== "undefined" && window.ethereum) {
        const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
        if (accounts && accounts.length > 0) {
          const account = accounts[0];
          const walletUser = {
            id: `wallet_${account.slice(2, 8)}`,
            name: `Wallet (${account.slice(0, 6)}...${account.slice(-4)})`,
            email: `${account.slice(0, 8).toLowerCase()}@eth.network`,
            role: "issuer",
            roleLabel: "Web3 Keyholder",
            roleIcon: "🦊",
            organization: "Ethereum Network",
            walletAddress: account,
            authType: "web3",
            loggedInAt: new Date().toISOString(),
          };
          setUser(walletUser);
          return walletUser;
        }
      }

      // Fallback: Simulated Web3 Wallet connection for testing
      await new Promise((resolve) => setTimeout(resolve, 800));
      const simulatedAddress = "0x8626f6940E2eb28930eFb4CeF49B2d1F2C9C1199";
      const simulatedUser = {
        id: "wallet_simulated_8626",
        name: "MetaMask User (0x8626...1199)",
        email: "signer@ethereum.local",
        role: "issuer",
        roleLabel: "Ethereum Signer",
        roleIcon: "🦊",
        organization: "Hardhat Local Node",
        walletAddress: simulatedAddress,
        authType: "web3",
        loggedInAt: new Date().toISOString(),
      };
      setUser(simulatedUser);
      return simulatedUser;
    } finally {
      setWalletConnecting(false);
    }
  };

  // Quick 1-click Demo Account Login
  const loginAsDemo = async (roleType = "issuer") => {
    await new Promise((resolve) => setTimeout(resolve, 350));
    const demo = DEMO_ACCOUNTS[roleType] || DEMO_ACCOUNTS.issuer;
    const activeDemoUser = {
      ...demo,
      loggedInAt: new Date().toISOString(),
    };
    setUser(activeDemoUser);
    return activeDemoUser;
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        walletConnecting,
        login,
        register,
        connectWallet,
        loginAsDemo,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
